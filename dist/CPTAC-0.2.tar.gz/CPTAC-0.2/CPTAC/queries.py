class Queries:
    def __init__(self, dataframe):
        self.dataframe = dataframe
    def query(self, tumor_type, query_type, value):
        pass
        #based on query_type
        #self.dataframe searched for value with type
