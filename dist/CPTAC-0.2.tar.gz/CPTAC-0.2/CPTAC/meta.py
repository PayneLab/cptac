class MetaData:
    def __init__(self, clinical, clinical_meta):
        self.clinical = clinical
        self.clinical_meta = clinical_meta
    def get_clinical(self):
        return self.clinical
    def get_clinical_meta(self):
        return self.clinical_meta
    
