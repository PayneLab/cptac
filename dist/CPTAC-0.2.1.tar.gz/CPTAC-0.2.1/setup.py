from setuptools import setup

setup(name='CPTAC',
	version='0.2.1',
	description='Python packaging for CPTAC data',
	long_description='A packaging system developed at Brigham Young University by David Adams, Sean Beecroft, and Samuel Payne for use with cancer dat. It is intended to be used to distribute datasets between researchers and data scientists.',
	url='http://github.com/PayneLab/CPTAC',
	author='Dr. Samuel Payne',
	author_email='sam_payne@byu.edu',
	license='Apache 2.0',
	packages=['CPTAC'],
	zip_safe=False,
	include_package_data=True
	)
